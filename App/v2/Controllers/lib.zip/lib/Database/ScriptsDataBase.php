<?php

namespace Lib\Database;

class ScriptsDataBase
{
    const SP_CREATE_TABLE = "SP_CREATE_TABLE";
    const SP_INSERT_TABLE = "SP_INSERT_TABLE";
    const SP_INSERT_TABLE_COLUMN = "SP_INSERT_TABLE_COLUMN";
}
